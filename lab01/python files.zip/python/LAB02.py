from ntpath import join

list_jack = ['Jack',':','How ','are ','you ','today ','?']
list_jim = ['Jim ',"I'm ",'well ','Thank ','you ','and ','you ','?']

print("".join(list_jack))
print("".join(list_jim))