celsius = 100
fahrenheit = (9/5*celsius)+32
print("Temperature in 100 Celsius =" + str(fahrenheit) + " Fahrenheit")