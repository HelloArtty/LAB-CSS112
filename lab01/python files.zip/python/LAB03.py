import math
square_root = 3
triple_root = 8
root2 = square_root**(1/2)
root3 = triple_root**(1/3)
print("The square root of 3.000 is %.3f"%root2)
print("The square root of 8.000 is %.3f"%root3)